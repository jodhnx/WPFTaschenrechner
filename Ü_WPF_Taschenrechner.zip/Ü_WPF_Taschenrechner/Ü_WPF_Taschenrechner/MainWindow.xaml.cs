﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ü_WPF_Taschenrechner
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double Zahl1 = Convert.ToDouble(tb_Z1.Text);
            double Zahl2 = Convert.ToDouble(tb_Z2.Text);
            double result = Zahl1 - Zahl2;
            tb_output.Text = result.ToString(tb_output.Text);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            double Zahl1 = Convert.ToDouble(tb_Z1.Text);
            double Zahl2 = Convert.ToDouble(tb_Z2.Text);
            double result = Zahl1 + Zahl2;
            tb_output.Text = result.ToString(tb_output.Text);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            double Zahl1 = Convert.ToDouble(tb_Z1.Text);
            double Zahl2 = Convert.ToDouble(tb_Z2.Text);
            double result = Zahl1 * Zahl2;
            tb_output.Text = result.ToString(tb_output.Text);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            double Zahl1 = Convert.ToDouble(tb_Z1.Text);
            double Zahl2 = Convert.ToDouble(tb_Z2.Text);
            double result = Zahl1 / Zahl2;
            tb_output.Text = result.ToString(tb_output.Text);
        }

        private void Button_Click4(object sender,EventArgs e) 
        {
            tb_Z1.Text = ("");
            tb_Z2.Text = ("");
        }
    }
}